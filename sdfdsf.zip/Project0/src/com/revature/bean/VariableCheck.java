package com.revature.bean;

//test
//trying to push Alphonse

public class VariableCheck {

	
	protected int menuOption;
	protected int carNumber;
	protected int offer;
	protected boolean login;
	protected boolean loop;
	
	/**
	 * @param employee the employee to set
	 */
	
	/**
	 * @return the menuOption
	 */
	public int getMenuOption() {
		return menuOption;
	}
	/**
	 * @param menuOption the menuOption to set
	 */
	public void setMenuOption(int menuOption) {
		this.menuOption = menuOption;
	}
	/**
	 * @return the login
	 */
	public boolean getLogin() {
		return login;
	}
	/**
	 * @param login the login to set
	 */
	public void setLogin(boolean login) {
		this.login = login;
	}
	/**
	 * @return the loop
	 */
	public boolean getLoop() {
		return loop;
	}
	/**
	 * @param loop the loop to set
	 */
	public void setLoop(boolean loop) {
		this.loop = loop;
	}
	/**
	 * @return the carNumber
	 */
	public int getCarNumber() {
		return carNumber;
	}
	/**
	 * @param carNumber the carNumber to set
	 */
	public void setCarNumber(int carNumber) {
		this.carNumber = carNumber;
	}
	/**
	 * @return the offer
	 */
	public int getOffer() {
		return offer;
	}
	/**
	 * @param offer the offer to set
	 */
	public void setOffer(int offer) {
		this.offer = offer;
	}
	/**
	 * @return the travelTo
	 */


	

}
